<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="outside" tilewidth="48" tileheight="48" tilecount="69344" columns="176">
 <image source="../Modern_Exteriors_Complete_Tileset_48x48.png" width="8448" height="18912"/>
</tileset>
