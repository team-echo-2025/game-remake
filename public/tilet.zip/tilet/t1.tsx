<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="t1" tilewidth="48" tileheight="48" tilecount="8588" columns="76">
 <image source="../Room_Builder_48x48.png" width="3648" height="5424"/>
</tileset>
