<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="zom1" tilewidth="48" tileheight="48" tilecount="144" columns="24">
 <image source="../Modern_Exteriors_Characters_Zombie_1_48x48.png" width="1152" height="288"/>
</tileset>
